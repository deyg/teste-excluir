package com.hdi.insurance.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HdIinsuranceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
